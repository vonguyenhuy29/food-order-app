import React from 'react';

const SidebarMenu = ({ selectedType }) => {
  const menuTypes = [
    "SNACK TRAVEL", "SNACK MENU", "CLUB MENU",
    "HOTEL MENU", "HOTEL MENU BEFORE 11AM", "HOTEL MENU AFTER 11PM",
    "VIP MENU", "WINE MENU - KOREAN", "WINE MENU - ENGLISH",
    "WINE MENU - CHINESE", "WINE MENU - JAPANESE"
  ];

  return (
    <div style={{
      width: '220px',
      background: '#111',
      color: 'white',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
      overflowY: 'auto',
      height: '100vh'
    }}>
      <h2 style={{ fontSize: '20px', marginBottom: '20px' }}>Admin Page</h2>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        {menuTypes.map(type => (
          <button
            key={type}
            onClick={() => window.location.href = `?type=${encodeURIComponent(type)}`}
            style={{
              background: type === selectedType ? '#fff' : '#333',
              color: type === selectedType ? '#000' : '#fff',
              padding: '10px',
              border: 'none',
              borderRadius: '5px',
              cursor: 'pointer',
              textAlign: 'left'
            }}
          >
            {type}
          </button>
        ))}
      </div>
    </div>
  );
};

export default SidebarMenu;
