import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AdminFoodList = ({ selectedType }) => {
  const [foods, setFoods] = useState([]);

  useEffect(() => {
    fetchFoods();
  }, []);

  const fetchFoods = async () => {
    const res = await axios.get(`${process.env.REACT_APP_API_URL}/api/foods`);
    setFoods(res.data);
  };

  const handleToggleStatus = async (id, currentStatus) => {
    const newStatus = currentStatus === "Available" ? "Sold Out" : "Available";
    await axios.post(`${process.env.REACT_APP_API_URL}/api/update-status/${id}`, { newStatus });
    fetchFoods();
  };

  const handleAddFood = async () => {
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/*';
    fileInput.multiple = true;

    fileInput.onchange = async (e) => {
      const files = Array.from(e.target.files);
      if (!files.length || !selectedType) return;

      for (const file of files) {
        const formData = new FormData();
        formData.append('image', file);
        formData.append('type', selectedType);

        try {
          const uploadRes = await axios.post(`${process.env.REACT_APP_API_URL}/api/upload`, formData);
          const imageUrl = uploadRes.data.imageUrl;
          if (imageUrl) {
            await axios.post(`${process.env.REACT_APP_API_URL}/api/foods`, { imageUrl, type: selectedType });
            fetchFoods();
          }
        } catch (err) {
          const imageUrl = err?.response?.data?.imageUrl;
          if (imageUrl) {
            await axios.post(`${process.env.REACT_APP_API_URL}/api/foods`, { imageUrl, type: selectedType });
            fetchFoods();
          } else {
            alert("Lỗi khi upload ảnh: " + err.message);
          }
        }
      }
    };

    fileInput.click();
  };

  const foodsByType = foods.filter(f => f.type?.trim().toUpperCase() === selectedType?.trim().toUpperCase());

  return (
    <div style={{
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden' // ❗ ngăn layout tràn
    }}>
      {/* Thanh điều khiển cố định */}
      <div style={{
        padding: '20px',
        borderBottom: '1px solid #ccc',
        background: '#fff8dc',
        flexShrink: 0
      }}>
        <h2 style={{ margin: 0 }}>{selectedType}</h2>
        <button onClick={handleAddFood} style={{
          marginTop: '10px',
          padding: '8px 16px',
          fontSize: '14px',
          cursor: 'pointer'
        }}>
          ➕ Thêm món mới
        </button>
      </div>

      {/* Danh sách ảnh – vùng có thể cuộn */}
      <div style={{
        flex: 1,
        overflowY: 'auto',
        padding: '20px',
        background: '#fff8dc',
        display: 'flex',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        {foodsByType.map(food => (
          <div key={food.id} style={{
            position: 'relative',
            width: '220px',
            border: '1px solid #ccc',
            borderRadius: '8px',
            overflow: 'hidden',
            cursor: 'pointer'
          }}
            onClick={() => handleToggleStatus(food.id, food.status)}
          >
            <img
              src={food.imageUrl}
              alt=""
              style={{
                width: '100%',
                height: 'auto',
                maxHeight: '240px',
                objectFit: 'contain'
              }}
            />
            {food.status === 'Sold Out' && (
              <div style={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: '100%',
                backgroundColor: 'rgba(0,0,0,0.5)',
                color: 'white',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                fontWeight: 'bold',
                fontSize: '20px'
              }}>
                SOLD OUT
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminFoodList;
