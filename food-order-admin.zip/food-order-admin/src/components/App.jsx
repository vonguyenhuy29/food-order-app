import React from 'react';
import SidebarMenu from './SidebarMenu';
import AdminFoodList from './AdminFoodList';

const App = () => {
  const params = new URLSearchParams(window.location.search);
  const selectedType = params.get('type') || "SNACK MENU";

  return (
    <div style={{
      display: 'flex',
      height: '100vh', // ❗ Quan trọng: chiều cao toàn màn hình
      overflow: 'hidden'
    }}>
      <SidebarMenu selectedType={selectedType} />
      
      {/* VÙNG NỘI DUNG BÊN PHẢI */}
      <div style={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column'
      }}>
        <AdminFoodList selectedType={selectedType} />
      </div>
    </div>
  );
};

export default App;
