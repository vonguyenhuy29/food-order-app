FOOD APP - USER INSIGHTS UPGRADE

Files to replace:
1. User frontend: src/components/FoodList.js
2. Backend: server.js

No change is required for AdminFoodList.jsx.

Main changes:
- User Insights layout upgraded to match Admin Insights.
- User Insights does not display the Price column or Spending tab.
- Added 4 overview cards: analyzed orders, customers, dishes, total item quantity.
- Added time filters: Today, 7 days, 30 days, This month, All time.
- Added richer top-dish table: quantity, order count, customer count, latest order, common notes.
- Added top-customer table with level, orders, item quantity, favorites and latest order.
- Click a customer to open the existing detailed customer profile.
- Kept customer events, order history, preferences and customer search.
- Added a public user-only overview API that removes the price field from its response.

After replacing files:
- Restart backend with PM2.
- Rebuild/restart User frontend.
- Hard refresh the browser once.
